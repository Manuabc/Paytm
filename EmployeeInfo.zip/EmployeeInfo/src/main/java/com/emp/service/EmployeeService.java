package com.emp.service;

import java.util.ArrayList;
import java.util.List;

import javax.print.attribute.standard.MediaSize.Other;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emp.entity.Employee;
import com.emp.repo.EmployeeRepo;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeRepo employeeRepo;
	
	
	public Employee saveEmployee(Employee emp) {
		return employeeRepo.save(emp);
		
		
		}
	
	public List<Employee> saveEmployees(List<Employee> emp) {
		return (List<Employee>) employeeRepo.saveAll(emp);
	}
	
	public List<Employee> getEmployees(){
		
		return (List<Employee>) employeeRepo.findAll();
		
				
	}
	
	public Employee getEmployeeById(int id) {
		return employeeRepo.findById(id).orElse(null);
		
		
	}
	
	public String deleteEmployee(int id) {
		employeeRepo.deleteById(id);
		return "product removed || "+id;
		
		
	}	
	
	public Employee updateEmployee(Employee emp) {
		Employee existingEmp=employeeRepo.findById(emp.getId()).orElse(null);
		existingEmp.setName(emp.getName());
		existingEmp.setSal(emp.getSal());
		existingEmp.setDesignation(emp.getDesignation());

		return employeeRepo.save(existingEmp);
	}
	

}
