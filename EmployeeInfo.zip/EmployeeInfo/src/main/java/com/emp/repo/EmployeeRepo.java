package com.emp.repo;

import javax.persistence.Id;

import org.springframework.data.repository.CrudRepository;

import com.emp.entity.Employee;

public interface EmployeeRepo extends CrudRepository<Employee, Integer> {

}
